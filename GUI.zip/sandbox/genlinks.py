lines = [line.rstrip('\n') for line in open('links.txt')]

print(" ".join(['-l'+str(line) for line in lines]))