#include "Application.h"
//////////////////////////////
//Why are you editing this??//
//////////////////////////////
int main()
{
	Application app;
	return app.run();
}
